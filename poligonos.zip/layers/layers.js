var wms_layers = [];


        var lyr_OSMStandard_0 = new ol.layer.Tile({
            'title': 'OSM Standard',
            'opacity': 1.000000,
            
            
            source: new ol.source.XYZ({
            attributions: ' &nbsp &middot; <a href="https://www.openstreetmap.org/copyright">© OpenStreetMap contributors, CC-BY-SA</a>',
                url: 'http://tile.openstreetmap.org/{z}/{x}/{y}.png'
            })
        });
var format_barriosseleccionados_1 = new ol.format.GeoJSON();
var features_barriosseleccionados_1 = format_barriosseleccionados_1.readFeatures(json_barriosseleccionados_1, 
            {dataProjection: 'EPSG:4326', featureProjection: 'EPSG:3857'});
var jsonSource_barriosseleccionados_1 = new ol.source.Vector({
    attributions: ' ',
});
jsonSource_barriosseleccionados_1.addFeatures(features_barriosseleccionados_1);
var lyr_barriosseleccionados_1 = new ol.layer.Vector({
                declutter: false,
                source:jsonSource_barriosseleccionados_1, 
                style: style_barriosseleccionados_1,
                popuplayertitle: 'barrios seleccionados',
                interactive: true,
                title: '<img src="styles/legend/barriosseleccionados_1.png" /> barrios seleccionados'
            });

lyr_OSMStandard_0.setVisible(true);lyr_barriosseleccionados_1.setVisible(true);
var layersList = [lyr_OSMStandard_0,lyr_barriosseleccionados_1];
lyr_barriosseleccionados_1.set('fieldAliases', {'REGION': 'REGION', 'PROVINCIA': 'PROVINCIA', 'COMUNA': 'COMUNA', 'Nombre': 'Nombre', });
lyr_barriosseleccionados_1.set('fieldImages', {'REGION': 'TextEdit', 'PROVINCIA': 'TextEdit', 'COMUNA': 'TextEdit', 'Nombre': 'TextEdit', });
lyr_barriosseleccionados_1.set('fieldLabels', {'REGION': 'no label', 'PROVINCIA': 'no label', 'COMUNA': 'no label', 'Nombre': 'no label', });
lyr_barriosseleccionados_1.on('precompose', function(evt) {
    evt.context.globalCompositeOperation = 'normal';
});
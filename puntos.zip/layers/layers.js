var wms_layers = [];


        var lyr_OSMStandard_0 = new ol.layer.Tile({
            'title': 'OSM Standard',
            'opacity': 1.000000,
            
            
            source: new ol.source.XYZ({
            attributions: ' &nbsp &middot; <a href="https://www.openstreetmap.org/copyright">© OpenStreetMap contributors, CC-BY-SA</a>',
                url: 'http://tile.openstreetmap.org/{z}/{x}/{y}.png'
            })
        });
var format_puntosturisticos_1 = new ol.format.GeoJSON();
var features_puntosturisticos_1 = format_puntosturisticos_1.readFeatures(json_puntosturisticos_1, 
            {dataProjection: 'EPSG:4326', featureProjection: 'EPSG:3857'});
var jsonSource_puntosturisticos_1 = new ol.source.Vector({
    attributions: ' ',
});
jsonSource_puntosturisticos_1.addFeatures(features_puntosturisticos_1);
var lyr_puntosturisticos_1 = new ol.layer.Vector({
                declutter: false,
                source:jsonSource_puntosturisticos_1, 
                style: style_puntosturisticos_1,
                popuplayertitle: 'puntos turisticos',
                interactive: true,
                title: '<img src="styles/legend/puntosturisticos_1.png" /> puntos turisticos'
            });

lyr_OSMStandard_0.setVisible(true);lyr_puntosturisticos_1.setVisible(true);
var layersList = [lyr_OSMStandard_0,lyr_puntosturisticos_1];
lyr_puntosturisticos_1.set('fieldAliases', {'Nombre': 'Nombre', 'Tipo': 'Tipo', 'comuna': 'comuna', 'barrio': 'barrio', 'Info.': 'Info.', });
lyr_puntosturisticos_1.set('fieldImages', {'Nombre': '', 'Tipo': '', 'comuna': '', 'barrio': '', 'Info.': '', });
lyr_puntosturisticos_1.set('fieldLabels', {'Nombre': 'inline label - always visible', 'Tipo': 'inline label - always visible', 'comuna': 'inline label - always visible', 'barrio': 'inline label - always visible', 'Info.': 'inline label - always visible', });
lyr_puntosturisticos_1.on('precompose', function(evt) {
    evt.context.globalCompositeOperation = 'normal';
});